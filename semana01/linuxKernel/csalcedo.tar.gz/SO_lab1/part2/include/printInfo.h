#ifndef PRINT_INFO_C
#define PRINT_INFO_C

#include "fileSearch.h"

void printFreeMemory();
void printModeTime();
void printKernelContextChangeRatio();
void printProcessCreationRatio();

#endif
