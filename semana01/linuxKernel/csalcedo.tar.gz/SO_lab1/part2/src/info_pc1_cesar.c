#include "printInfo.h"

int main (void) {
	printFreeMemory();
	printModeTime();
	printKernelContextChangeRatio();
	
	return 0;
}
